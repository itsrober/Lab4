package com.example.flutter_application_lab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
