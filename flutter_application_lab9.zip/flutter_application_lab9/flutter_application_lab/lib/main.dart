
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(MyApp());
}
//Espacio
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'News App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: NewsScreen(),
    );
  }
}
//Espacio


class NewsScreen extends StatefulWidget {
  @override
  _NewsScreenState createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  final String apiUrl =
      "https://newsapi.org/v2/everything?q=tesla&from=2024-04-16&sortBy=publishedAt&apiKey=21a249d6d07348bbaba1ab203e50e5ae";

  List<dynamic> _articles = [];

  Future<void> _fetchNews() async {
    var response = await http.get(Uri.parse(apiUrl));
    var jsonData = jsonDecode(response.body);

    setState(() {
      _articles = jsonData['articles'];
    });
  }

  @override
  void initState() {
    super.initState();
    _fetchNews();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tesla News'),
      ),
      body: _articles.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _articles.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(_articles[index]['title']),
                  subtitle: Text(_articles[index]['description'] ?? ''),
                  onTap: () {
                    // Add here what you want to do when a news item is tapped
                  },
                );
              },
            ),
    );
  }
}
